package Business.Utilizador;

public class Gestor extends Utilizador {

    public Gestor() {
        super();
    }

    public Gestor(String numero, String password) {
        super(numero,password);
    }

    public Gestor(Gestor gestor) {
        super(gestor);
    }

    // gets

    // sets

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("Tipo de utilizador: gestor").append("\n");
        return sb.toString();
    }

    // clone
    public Gestor clone() {
        return new Gestor(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Gestor gestor = (Gestor) obj;
        return  super.equals(gestor);
    }
}
