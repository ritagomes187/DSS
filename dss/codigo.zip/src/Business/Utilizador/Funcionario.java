package Business.Utilizador;

public class Funcionario extends Utilizador {

    private int rececoes; // numero de rececoes realizadas
    private int entregas; // numero de entregas realizadas

    public Funcionario() {
        super();
        this.rececoes = 0;
        this.entregas = 0;
    }

    public Funcionario(String numero, String password, int rececoes, int entregas) {
        super(numero,password);
        this.rececoes = rececoes;
        this.entregas = entregas;
    }

    public Funcionario(Funcionario funcionario) {
        super(funcionario);
        this.rececoes = funcionario.getRececoes();
        this.entregas = funcionario.getEntregas();
    }

    // gets
    public int getRececoes() {
        return this.rececoes;
    }
    public int getEntregas() {
        return this.entregas;
    }

    // sets
    public void setRececoes(int rececoes) {
        this.rececoes = rececoes;
    }
    public void setEntregas(int entregas) {
        this.entregas = entregas;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("     Número de receções: ").append(this.rececoes).append("\n");
        sb.append("     Número de entregas: ").append(this.entregas).append("\n");
        return sb.toString();
    }

    // clone
    public Funcionario clone() {
        return new Funcionario(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Funcionario funcionario = (Funcionario) obj;
        return  super.equals(funcionario) &&
                this.rececoes == funcionario.getRececoes() &&
                this.entregas == funcionario.getEntregas();
    }

    // metodos
    public void incrementaRececoes() {
        this.rececoes++;
    }

    public void incrementaEntregas() {
        this.entregas++;
    }
}
