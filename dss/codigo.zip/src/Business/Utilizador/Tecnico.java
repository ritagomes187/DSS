package Business.Utilizador;

public class Tecnico extends Utilizador {

    private int programadas;    // numero de reparacoes programadas
    private int expresso;       // numero de reparações expresso
    private int tempoTrabalho;  // tempo total de trabalho exercido em servicos programados em minutos

    public Tecnico() {
        super();
        this.programadas = 0;
        this.expresso = 0;
        this.tempoTrabalho = 0;
    }

    public Tecnico(String numero, String password, int programadas, int expresso, int tempoTrabalho) {
        super(numero,password);
        this.programadas = programadas;
        this.expresso = expresso;
        this.tempoTrabalho = tempoTrabalho;
    }

    public Tecnico(Tecnico tecnico) {
        super(tecnico);
        this.programadas = tecnico.getProgramadas();
        this.expresso = tecnico.getExpresso();
        this.tempoTrabalho = tecnico.getTempoTrabalho();
    }

    // gets
    public int getProgramadas() {
        return this.programadas;
    }
    public int getExpresso() {
        return this.expresso;
    }
    public int getTempoTrabalho() {
        return this.tempoTrabalho;
    }

    // sets
    public void setProgramadas(int programadas) {
        this.programadas = programadas;
    }
    public void setExpresso(int expresso) {
        this.expresso = expresso;
    }
    public void setTempoTrabalho(int tempoTrabalho) {
        this.tempoTrabalho = tempoTrabalho;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("     Número de reparações programadas: ").append(this.programadas).append("\n");
        sb.append("     Número de reparações expresso: ").append(this.expresso).append("\n");
        float media = 0;
        if (this.programadas != 0) media = (float) this.tempoTrabalho/this.programadas;
        sb.append("     Tempo médio das reparações programadas: ").append(media).append(" minutos").append("\n");
        return sb.toString();
    }

    // clone
    public Tecnico clone() {
        return new Tecnico(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Tecnico tecnico = (Tecnico) obj;
        return  super.equals(tecnico) &&
                this.programadas == tecnico.getProgramadas() &&
                this.expresso == tecnico.getExpresso() &&
                this.tempoTrabalho == tecnico.getTempoTrabalho();
    }

    // metodos
    public void incrementaServicoProgramado() {
        this.programadas++;
    }

    public void incrementaServicoExpresso() {
        this.expresso++;
    }

    public void registaTempoTrabalho(int tempo) {
        this.tempoTrabalho += tempo;
    }
}
