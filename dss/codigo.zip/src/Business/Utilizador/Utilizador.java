package Business.Utilizador;

public abstract class Utilizador {

    private String numero;      // número de utilizador
    private String password;    // password do utilizador

    public Utilizador() {
        this.numero = "n/a";
        this.password = "n/a";
    }

    public Utilizador(String numero, String password) {
        this.numero = numero;
        this.password = password;
    }

    public Utilizador(Utilizador utilizador) {
        this.numero = utilizador.getNumero();
        this.password = utilizador.getPassword();
    }

    // gets
    public String getNumero() {
        return this.numero;
    }
    public String getPassword() {
        return this.password;
    }

    // sets
    public void setNumero(String numero) {
        this.numero = numero;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.numero).append("\n");
        return sb.toString();
    }

    // clone
    public abstract Utilizador clone();

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Utilizador utilizador = (Utilizador) obj;
        return  this.numero.equals(utilizador.getNumero()) &&
                this.password.equals(utilizador.getPassword());
    }
}
