package Business;

import Business.Registo.Identificador;
import Business.Servico.*;
import Business.Utilizador.Funcionario;
import Business.Utilizador.Gestor;
import Business.Utilizador.Tecnico;
import Business.Utilizador.Utilizador;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NOTAS:
 *      faltou lidar com as exceções...
 */

public class UseCases {

    CentroReparacoesFacade centro;  // centro de reparações
    Utilizador user;                // utilizador atual do sistema

    public UseCases() {
        this.centro = new CentroReparacoesFacade();
        povoarCentro();     // so para testagem
    }

    public UseCases(CentroReparacoesFacade centro, Utilizador user) {
        this.centro = centro.clone();
        this.user = user.clone();
    }

    public UseCases(UseCases useCases) {
        this.centro = useCases.getCentro();
        this.user = useCases.getUser();
    }

    // gets
    public CentroReparacoesFacade getCentro() {
        return this.centro.clone();
    }
    public Utilizador getUser() {
        return this.user.clone();
    }

    // sets
    public void setCentro(CentroReparacoesFacade centro) {
        this.centro = centro.clone();
    }
    public void setUser(Utilizador user) {
        this.user = user.clone();
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ESTADO ATUAL\n\n\n");
        sb.append(this.centro.toString());
        sb.append("User ").append(this.user.toString());
        return sb.toString();
    }

    // clone
    public UseCases clone() {
        return new UseCases(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        UseCases useCases = (UseCases) obj;
        return  this.centro.equals(useCases.getCentro()) &&
                this.user.equals(useCases.getUser());
    }


    // use case dos utilizadores

    public boolean autenticacao(String numero, String password) {
        boolean validado = this.centro.validaCredenciais(numero,password);
        if (validado) setUser(this.centro.getUtilizadores().get(numero));
        return validado;
    }


    // use cases dos funcionarios

    public void registarEntregaEquipamentoPeloCliente(int nif, String tipoServico, String tlm, String email, String nome, String descricao) {
        Identificador id = new Identificador(nif);
        Funcionario funcionario = (Funcionario) this.user;

        Servico servico = null;
        if (tipoServico.equals("programado"))
            servico = new ServicoProgramado();
        if (tipoServico.equals("expresso")) {
            if (this.centro.verificaServicoExpresso())
                servico = new ServicoExpresso();
            else {
                System.out.println("Não existe disponibilidade para realizar o serviço expresso !!!");
                return;
            }
        }

        boolean existe = this.centro.getFichas().containsKey(id.getNif());
        boolean entrega = this.centro.getFichas().get(id.getNif()).getEntrega();
        if (existe && !entrega) {
            System.out.println("De momento apenas é possível suportar 1 equipamento por cliente...");
            return;
        }

        LocalDateTime data = LocalDateTime.now();
        this.centro.criaFicha(id,tlm,email,nome,descricao,data,funcionario,servico);
        this.centro.incrementaRececao(funcionario);
        System.out.println("Registo de entrega efetuado !!!");
    }

    public void registarPedidoOrcamento(int nif) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        Servico servico = this.centro.getFichas().get(id.getNif()).getServico();
        if (servico instanceof ServicoExpresso) {
            System.out.println("Serviços expresso não usufruem de pedidos de orçamento !!!");
            return;
        }

        boolean pedidoOrcamento = ((ServicoProgramado) servico).getPedidoOrcamento();
        if (pedidoOrcamento) {
            System.out.println("Pedido de orçamento já foi realizado previamente !!!");
            return;
        }

        this.centro.anotaPedidoOrcamento(id);
        this.centro.addPedidoOrcamento(id);
        System.out.println("Registo do pedido de orçamento efetuado !!!");
    }

    public void confirmacaoPedidoOrcamento(int nif, String resposta) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        Servico servico = this.centro.getFichas().get(id.getNif()).getServico();
        if (servico instanceof ServicoExpresso) {
            System.out.println("Serviços expresso não usufruem de pedidos de orçamento !!!");
            return;
        }

        boolean pedidoOrcamento = this.centro.getListaPedidosOrcamento().contains(id);
        if (!pedidoOrcamento) {
            System.out.println("Não foi realizado nenhum pedido de orçamento !!!");
            return;
        }

        boolean confirmacao = resposta.equals("sim");
        this.centro.anotaConfirmacaoOrcamento(id,confirmacao);

        if (confirmacao) this.centro.addEquipamentoPorReparar(id);
        else {
            this.centro.anotaReparacao(id,"nao efetuada");
            this.centro.anotaPagamento(id);
            this.centro.addEquipamentoReparado(id);
        }

        this.centro.eliminaPedidoOrcamento(id);
        System.out.println("Resposta ao pedido de orçamento anotada !!!");
    }

    public void registarPagamento(int nif) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        boolean reparado = this.centro.getListaEquiReparados().contains(id);
        if (!reparado) {
            System.out.println("O equipamento ainda não foi reparado !!!");
            return;
        }

        this.centro.anotaPagamento(id);
        System.out.println("Registo do pagamento efetuado !!!");
    }

    public void registarEntregaEquipamentoPeloFuncionario(int nif) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        boolean pagamento = this.centro.verificaPagamento(id);
        if (!pagamento) {
            System.out.println("O pagamento desta reparação ainda não foi realizado !!!");
            return;
        }

        Funcionario funcionario = (Funcionario) this.user;

        this.centro.anotaEntrega(id,funcionario);
        this.centro.incrementaEntrega(funcionario);
        this.centro.eliminaEquipamentoReparado(id);
        System.out.println("Registo da entrega do equipamento efetuado !!!");
    }


    // use cases dos tecnicos

    public List<Identificador> acederPedidosOrcamento() {
        return this.centro.getListaPedidosOrcamento();
    }

    public void registarPlanoTrabalhos(int nif, List<Etapa> plano) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        this.centro.anotaPlano(id,plano);

        int etapas = plano.size();
        if (etapas == 0) { // nao tem reparacao
            this.centro.anotaReparacao(id,"nao efetuada");
            this.centro.eliminaEquipamentoPorReparar(id);
            this.centro.addEquipamentoReparado(id);
        }
        else {
            Orcamento orcamento = this.centro.calculaOrcamento(plano);
            this.centro.anotaOrcamento(id,orcamento);
        }

        System.out.println("Registo do plano de trabalhos efetuado !!!");
    }

    public List<Identificador> acederEquipamentosPorReparar() {
        return this.centro.getListaEquiPorReparar();
    }

    public void realizarReparacao(int nif) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        ServicoProgramado servico = (ServicoProgramado) this.centro.getFichas().get(id.getNif()).getServico();
        if (servico == null) {
            System.out.println("Serviços expresso não tem plano de trabalho !!!");
            return;
        }

        boolean reparacao = this.centro.realizaEtapas(servico);

        if (reparacao)
            System.out.println("Reparação efetuada com sucesso");
        else {
            this.centro.anotaReparacao(id,"em espera");
            System.out.print("O técnico interrompeu a reparação...");
            boolean orcamentoExcedido = servico.orcamentoExcedido();
            if (orcamentoExcedido) {
                this.centro.anotaContactoCliente(servico,LocalDateTime.now());
                System.out.println("porque o orçamento da reparação foi excedido.");
            }
            else
                System.out.println("por falta de tempo ou peças.");
        }
    }

    public void registarConclusaoReparacao(int nif) {
        Identificador id = new Identificador(nif);
        if (!this.centro.validaNif(id)) {
            System.out.println("Não existe nenhuma ficha com o NIF fornecido !!!");
            return;
        }

        Servico servico = this.centro.getFichas().get(id.getNif()).getServico();

        if (servico instanceof ServicoExpresso)
            this.centro.incrementaServicoExpresso(servico.getTecnico());

        if (servico instanceof ServicoProgramado) {
            this.centro.incrementaServicoProgramado(servico.getTecnico());
            int tempo = 0;
            for (Etapa etapa: ((ServicoProgramado) servico).getPlanoTrabalhos())
                 tempo += etapa.getTempoReal();
            this.centro.registaTempoTrabalho(servico.getTecnico(), tempo);
        }

        this.centro.anotaReparacao(id,"efetuada");
        this.centro.eliminaEquipamentoReparado(id);
        this.centro.addEquipamentoReparado(id);
        System.out.println("Registo da conclusão de reparação efetuado !!!");
    }


    // use cases do gestor

    public String consultarListaTecnicos() {
        return this.centro.calcularListaTecnicos();
    }

    public String consultarListaFuncionarios() {
        return this.centro.calcularListaFuncionarios();
    }

    public String consultarListaExaustivaTecnicos() {
        return this.centro.calcularListaExaustivaTecnicos();
    }




    // script para testar o programa

    public void povoarCentro() {

        // utilizadores
        Map<String,Utilizador> utilizadores = new HashMap<>();

        // funcionarios
        Funcionario f1 = new Funcionario("#001","#1",0,20);
        Funcionario f2 = new Funcionario("#002","#2",5,15);
        Funcionario f3 = new Funcionario("#003","#3",10,10);
        Funcionario f4 = new Funcionario("#004","#4",15,5);
        Funcionario f5 = new Funcionario("#005","#5",20,0);

        utilizadores.put("#001",f1);
        utilizadores.put("#002",f2);
        utilizadores.put("#003",f3);
        utilizadores.put("#004",f4);
        utilizadores.put("#005",f5);

        // tecnicos
        Tecnico t1 = new Tecnico("$001","$1",0,0,0);
        Tecnico t2 = new Tecnico("$002","$2",1,1,10);
        Tecnico t3 = new Tecnico("$003","$3",2,2,20);
        Tecnico t4 = new Tecnico("$004","$4",3,3,30);
        Tecnico t5 = new Tecnico("$005","$5",4,4,40);
        Tecnico t6 = new Tecnico("$006","$6",5,5,50);
        Tecnico t7 = new Tecnico("$007","$7",6,6,60);
        Tecnico t8 = new Tecnico("$008","$8",7,7,70);
        Tecnico t9 = new Tecnico("$009","$9",8,8,80);
        Tecnico t10 = new Tecnico("$010","$10",9,9,90);

        utilizadores.put("$001",t1);
        utilizadores.put("$002",t2);
        utilizadores.put("$003",t3);
        utilizadores.put("$004",t4);
        utilizadores.put("$005",t5);
        utilizadores.put("$006",t6);
        utilizadores.put("$007",t7);
        utilizadores.put("$008",t8);
        utilizadores.put("$009",t9);
        utilizadores.put("$010",t10);

        // Gestor
        Gestor g1 = new Gestor("%001","%1");

        utilizadores.put("%001",g1);

        // atualiza centro
        this.centro.setUtilizadores(utilizadores);
    }
}
