package Business;

import Business.Registo.Identificador;
import Business.Servico.Etapa;
import Business.Servico.Orcamento;
import Business.Servico.Servico;
import Business.Servico.ServicoProgramado;
import Business.Utilizador.Funcionario;

import java.time.LocalDateTime;
import java.util.List;

public interface IRegistos {

    /**
     * Método responsável por criar uma ficha de registos para um equipamento.
     * @param id Identificador, nif do cliente
     * @param tlm Número telemóvel do cliente
     * @param email Contacto email do cliente
     * @param nome Nome do equipamento
     * @param descricao Descrição do problema
     * @param rececao Data de receção do equipamento pelo funcionário
     * @param f1 Funcionário responsável pela receção
     * @param servico Serviço a ser prestado
     */
    void criaFicha(Identificador id, String tlm, String email, String nome, String descricao, LocalDateTime rececao, Funcionario f1, Servico servico);

    /**
     * Método responsável por anotar a realização do pedido de orçamento pelo cliente
     * @param id Identificador, nif do cliente
     */
    void anotaPedidoOrcamento(Identificador id);

    /**
     * Método responsável por anotar a resposta do cliente em relação ao pedido de orçamento
     * @param id Identificador, nif do cliente
     * @param resposta true, se aceitou, false caso contrário
     */
    void anotaConfirmacaoOrcamento(Identificador id, boolean resposta);

    /**
     * Método responsável por anotar o estado da reparação
     * efetuada: reparação concluída
     * nao efetuada: reparação não concluída (cliente rejeita orçamento ou não tem reparação)
     * em espera: reparação em espera (falta de peças ou necessita de nova confirmação do cliente)
     * @param id Identificador, nif do cliente
     * @param reparacao Estado da reparação
     */
    void anotaReparacao(Identificador id, String reparacao);

    /**
     * Método responsável por anotar o pagamento do serviço realizado
     * @param id Identificador, nif do cliente
     */
    void anotaPagamento(Identificador id);

    /**
     * Método responsável por anotar a entrega do equipamento e o funcionário responsável pela mesma
     * @param id Identificador, nif do cliente
     * @param funcionario Funcionário responsável pela entrega
     */
    void anotaEntrega(Identificador id, Funcionario funcionario);

    /**
     * Método responsável por anotar o plano de trabalhos de um serviço programado
     * @param id Identificador, nif do cliente
     * @param plano Plano a anotar
     */
    void anotaPlano(Identificador id, List<Etapa> plano);

    /**
     * Método responsável por anotar o orçamento de um serviço programado
     * @param id Identificador, nif do cliente
     * @param orcamento Orçamento a registar
     */
    void anotaOrcamento(Identificador id, Orcamento orcamento);

    /**
     * Método responsável por verificar se existe alguma ficha de registo com o Identificador fornecido
     * @param id Identificador, nif do cliente
     * @return true, se existir, false caso contrário
     */
    boolean validaNif(Identificador id);

    /**
     * Método responsável por verificar a disponibilidade de realizar um serviço expresso
     * @return true, se tiver disponível, false caso contrário
     */
    boolean verificaServicoExpresso();

    /**
     * Método responsável por verificar se um pagamento já foi efetuado ou não
     * @param id Identificador, nif do cliente
     * @return true, se foi realizado, false caso contrário
     */
    boolean verificaPagamento(Identificador id);

    /**
     * Método responsável por adicionar um Identificador à lista de pedidos de orçamento
     * @param id Identificador, nif do cliente
     */
    void addPedidoOrcamento(Identificador id);

    /**
     * Método responsável por adicionar um Identificador à lista de equipamentos por reparar
     * @param id Identificador, nif do cliente
     */
    void addEquipamentoPorReparar(Identificador id);

    /**
     * Método responsável por adicionar um Identificador à lista de equipamentos reparados
     * @param id Identificador, nif do cliente
     */
    void addEquipamentoReparado(Identificador id);

    /**
     * Método responsável por eliminar um Identificador da lista de pedidos de orçamento
     * @param id Identificador, nif do cliente
     */
    void eliminaPedidoOrcamento(Identificador id);

    /**
     * Método responsável por eliminar um Identificador da lista de equipamentos por reparar
     * @param id Identificador, nif do cliente
     */
    void eliminaEquipamentoPorReparar(Identificador id);

    /**
     * Método responsável por eliminar um Identificador da lista de equipamentos reparados
     * @param id Identificador, nif do cliente
     */
    void eliminaEquipamentoReparado(Identificador id);

    /**
     * Método responsável por calcular um orçamento com base num plano de trabalhos
     * @param plano Plano de trabalhos
     * @return Orçamento calculado
     */
    Orcamento calculaOrcamento(List<Etapa> plano);

    /**
     * Método responsável por receber e registar o custo e tempo real de cada Etapa de um
     * plano de trabalhos de um determinado Servico. O técnico é quem fornece estes dados.
     * @param servico O servico
     * @return true, se a reparação foi concluida, false caso tenha ficado em espera
     */
    boolean realizaEtapas(ServicoProgramado servico);

    /**
     * Método responsável por fazer o registo do contacto realizado com o cliente.
     * @param servico Serviço que teve o orçamento excedido
     * @param data Data em que o cliente foi contactado
     */
    void anotaContactoCliente(ServicoProgramado servico, LocalDateTime data);
}
