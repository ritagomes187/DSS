package Business.Registo;

public class Identificador {

    private int nif;    // nif do cliente

    public Identificador(int nif) {
        this.nif = nif;
    }

    public Identificador(Identificador identificador) {
        this.nif = identificador.getNif();
    }

    // gets
    public int getNif() {
        return this.nif;
    }

    // sets
    public void setNif(int nif) {
        this.nif = nif;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.nif).append("\n");
        return sb.toString();
    }

    // clone
    public Identificador clone() {
        return new Identificador(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Identificador id = (Identificador) obj;
        return  this.nif == id.getNif();
    }
}
