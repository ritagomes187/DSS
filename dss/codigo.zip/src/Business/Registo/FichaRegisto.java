package Business.Registo;

import Business.Servico.Servico;
import Business.Utilizador.Funcionario;

import java.time.LocalDateTime;

public class FichaRegisto {

    private Identificador id;               // identificador
    private String tlm;
    private String email;
    private String nome;                    // nome do equipamento
    private String descricao;               // descrição do problema
    private String reparacao;               // efetuada | nao efetuada | em espera (falta de peças ou confirmação do cliente)
    private boolean pagamento;
    private boolean entrega;
    private LocalDateTime rececao;          // data da receção do equipamento
    private LocalDateTime levantamento;     // data da entrega do equipamento
    private Funcionario f1;                 // funcionario responsavel pela rececao
    private Funcionario f2;                 // funcionario responsavel pela entrega
    private Servico servico;                // tipo servico programado ou expresso


    public FichaRegisto(Identificador id,String tlm,String email,
                        String nome,String descricao,LocalDateTime rececao,
                        Funcionario f1, Servico servico) {
        this.id = id.clone();
        this.tlm = tlm;
        this.email = email;
        this.nome = nome;
        this.descricao = descricao;
        this.rececao = rececao;
        this.f1 = f1.clone();
        this.f2 = new Funcionario();
        this.servico = servico.clone();
    }

    public FichaRegisto(FichaRegisto fichaRegisto) {
        this.id = fichaRegisto.getId();
        this.tlm = fichaRegisto.getTlm();
        this.email = fichaRegisto.getEmail();
        this.nome = fichaRegisto.getNome();
        this.descricao = fichaRegisto.getDescricao();
        this.reparacao = fichaRegisto.getReparacao();
        this.pagamento = fichaRegisto.getPagamento();
        this.entrega = fichaRegisto.getEntrega();
        this.rececao = fichaRegisto.getRececao();
        this.levantamento = fichaRegisto.getLevantamento();
        this.f1 = fichaRegisto.getF1();
        this.f2 = fichaRegisto.getF2();
        this.servico = fichaRegisto.getServico();
    }

    // gets
    public Identificador getId() {
        return this.id.clone();
    }
    public String getTlm() {
        return this.tlm;
    }
    public String getEmail() {
        return this.email;
    }
    public String getNome() {
        return this.nome;
    }
    public String getDescricao() {
        return this.descricao;
    }
    public String getReparacao() {
        return this.reparacao;
    }
    public boolean getPagamento() {
        return this.pagamento;
    }
    public boolean getEntrega() {
        return this.entrega;
    }
    public LocalDateTime getRececao() {
        return this.rececao;
    }
    public LocalDateTime getLevantamento() {
        return this.levantamento;
    }
    public Funcionario getF1() {
        return this.f1.clone();
    }
    public Funcionario getF2() {
        return this.f2.clone();
    }
    public Servico getServico() {
        return this.servico.clone();
    }

    // sets
    public void setId(Identificador id) {
        this.id = id;
    }
    public void setTlm(String tlm) {
        this.tlm = tlm;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public void setReparacao(String reparacao) {
        this.reparacao = reparacao;
    }
    public void setPagamento(boolean pagamento) {
        this.pagamento = pagamento;
    }
    public void setEntrega(boolean entrega) {
        this.entrega = entrega;
    }
    public void setRececao(LocalDateTime rececao) {
        this.rececao = rececao;
    }
    public void setLevantamento(LocalDateTime levantamento) {
        this.levantamento = levantamento;
    }
    public void setF1(Funcionario f1) {
        this.f1 = f1.clone();
    }
    public void setF2(Funcionario f2) {
        this.f2 = f2.clone();
    }
    public void setServico(Servico servico) {
        this.servico = servico.clone();
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder("FICHA DE REGISTO | ").append(this.nome).append("\n");
        sb.append("Identificador ").append(this.id.toString());
        sb.append("Telemovel: ").append(this.tlm).append("\n");
        sb.append("Email: ").append(this.email).append("\n");
        sb.append("Descrição problema: ").append(this.descricao).append("\n");
        sb.append("Dados do serviço\n").append(this.servico.toString());
        sb.append("Estado da reparação: ").append(this.reparacao).append("\n");
        sb.append("Data de receção: ").append(this.rececao).append("\n");
        sb.append("Funcionário responsável pela receção: ").append(this.f1.toString());
        sb.append("Pagamento efetuado ? ").append(this.pagamento).append("\n");
        sb.append("Entrega efetuada ? ").append(this.entrega).append("\n");
        sb.append("Data de levantamento: ").append(this.levantamento).append("\n");
        sb.append("Funcionário responsável pela entrega/levantamento: ").append(this.f2.toString());
        return sb.toString();
    }

    // clone
    public FichaRegisto clone() {
        return new FichaRegisto(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        FichaRegisto ficha = (FichaRegisto) obj;
        return  this.id.equals(ficha.getId());
    }
}