package Business;

import Business.Registo.FichaRegisto;
import Business.Registo.Identificador;
import Business.Servico.Etapa;
import Business.Servico.Orcamento;
import Business.Servico.Servico;
import Business.Servico.ServicoProgramado;
import Business.Utilizador.Funcionario;
import Business.Utilizador.Tecnico;
import Business.Utilizador.Utilizador;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * NOTAS:
 *      as listagens tao imcompletas
 *
 *      pensar num critério para a disponibilidade do serviço expresso (este nao faz sentido, so para teste)
 */


public class CentroReparacoesFacade implements IRegistos, IUtilizadores {

    private Map<Integer,FichaRegisto> fichas;               // Fichas de registo (chave é o nif do Identificador).
    private Map<String,Utilizador> utilizadores;            // Utilizadores (chave é o numero associado ao utilizador).
    private List<Identificador> listaEquiReparados;         // Lista com os ids dos equipamentos ja reparados.
    private List<Identificador> listaEquiPorReparar;        // Lista com os ids dos equipamentos não reparados.
    private List<Identificador> listaPedidosOrcamento;      // Lista com os ids dos equipamentos que necessitam de um orcamento.

    public CentroReparacoesFacade() {
        this.fichas = new HashMap<>();
        this.utilizadores = new HashMap<>();
        this.listaEquiReparados = new ArrayList<>();
        this.listaEquiPorReparar = new ArrayList<>();
        this.listaPedidosOrcamento = new ArrayList<>();
    }

    public CentroReparacoesFacade(Map<Integer, FichaRegisto> fichas, Map<String,
                                   Utilizador> utilizadores, List<Identificador> listaEquiReparados,
                                  List<Identificador> listaEquiPorReparar, List<Identificador> listaPedidosOrcamento) {
        this.fichas = fichas.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e->e.getValue().clone()));
        this.utilizadores = utilizadores.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e->e.getValue().clone()));
        this.listaEquiReparados = listaEquiReparados.stream().map(Identificador::clone).collect(Collectors.toList());
        this.listaEquiPorReparar = listaEquiPorReparar.stream().map(Identificador::clone).collect(Collectors.toList());
        this.listaPedidosOrcamento = listaPedidosOrcamento.stream().map(Identificador::clone).collect(Collectors.toList());
    }

    public CentroReparacoesFacade(CentroReparacoesFacade ICRF) {
        this.fichas = ICRF.getFichas();
        this.utilizadores = ICRF.getUtilizadores();
        this.listaEquiReparados = ICRF.getListaEquiReparados();
        this.listaEquiPorReparar = ICRF.getListaEquiPorReparar();
        this.listaPedidosOrcamento = ICRF.getListaPedidosOrcamento();
    }

    // gets
    public Map<Integer, FichaRegisto> getFichas() {
        return this.fichas.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,e-> e.getValue().clone()));
    }
    public Map<String, Utilizador> getUtilizadores() {
        return this.utilizadores.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,e-> e.getValue().clone()));
    }
    public List<Identificador> getListaEquiReparados() {
        return this.listaEquiReparados.stream().map(Identificador::clone).collect(Collectors.toList());
    }
    public List<Identificador> getListaEquiPorReparar() {
        return this.listaEquiPorReparar.stream().map(Identificador::clone).collect(Collectors.toList());
    }
    public List<Identificador> getListaPedidosOrcamento() {
        return this.listaPedidosOrcamento.stream().map(Identificador::clone).collect(Collectors.toList());
    }

    // sets
    public void setFichas(Map<Integer, FichaRegisto> fichas) {
        this.fichas = fichas.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e-> e.getValue().clone()));
    }
    public void setUtilizadores(Map<String, Utilizador> utilizadores) {
        this.utilizadores = utilizadores.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e-> e.getValue().clone()));
    }
    public void setListaEquiReparados(List<Identificador> listaEquiReparados) {
        this.listaEquiReparados = listaEquiReparados.stream().map(Identificador::clone).collect(Collectors.toList());
    }
    public void setListaEquiPorReparar(List<Identificador> listaEquiPorReparar) {
        this.listaEquiPorReparar = listaEquiPorReparar.stream().map(Identificador::clone).collect(Collectors.toList());
    }
    public void setListaPedidosOrcamento(List<Identificador> listaPedidosOrcamento) {
        this.listaPedidosOrcamento = listaPedidosOrcamento.stream().map(Identificador::clone).collect(Collectors.toList());
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("DADOS DO CENTRO DE REPARAÇÕES\n\n\n");
        sb.append("FICHAS:\n").append(this.fichas.toString()).append("\n\n");
        sb.append("UTILIZADORES:\n").append(this.utilizadores.toString()).append("\n\n");
        sb.append("Equipamentos reparados:\n").append(this.listaEquiReparados.toString()).append("\n\n");
        sb.append("Equipamentos por reparar:\n").append(this.listaEquiPorReparar.toString()).append("\n\n");
        sb.append("Equipamentos à espera de orcamento:\n").append(this.listaPedidosOrcamento.toString()).append("\n\n");
        return sb.toString();
    }

    // clone
    public CentroReparacoesFacade clone() {
        return new CentroReparacoesFacade(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        CentroReparacoesFacade centro = (CentroReparacoesFacade) obj;
        return  this.fichas.equals(centro.getFichas()) &&
                this.utilizadores.equals(centro.getUtilizadores()) &&
                this.listaEquiReparados.equals(centro.getListaEquiReparados()) &&
                this.listaEquiPorReparar.equals(centro.getListaEquiPorReparar()) &&
                this.listaPedidosOrcamento.equals(centro.getListaPedidosOrcamento());
    }

    // metodos gestao registos
    @Override
    public void criaFicha(Identificador id, String tlm, String email, String nome, String descricao, LocalDateTime rececao, Funcionario f1, Servico servico) {
        // criar ficha
        FichaRegisto ficha = new FichaRegisto(id, tlm, email, nome, descricao, rececao, f1, servico);
        // adicionar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaPedidoOrcamento(Identificador id) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // servico associado (tem de ser programado)
        ServicoProgramado servico = (ServicoProgramado) ficha.getServico();
        // anotar pedido
        servico.setPedidoOrcamento(true);
        // registar na ficha
        ficha.setServico(servico);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaConfirmacaoOrcamento(Identificador id, boolean resposta) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // servico associado (tem de ser programado)
        ServicoProgramado servico = (ServicoProgramado) ficha.getServico();
        // anotar confirmacao
        servico.setConfirmacaoOrcamento(resposta);
        // registar na ficha
        ficha.setServico(servico);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaReparacao(Identificador id, String reparacao) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // anota reparacao
        ficha.setReparacao(reparacao);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaPagamento(Identificador id) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // anota pagamento
        ficha.setPagamento(true);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaEntrega(Identificador id, Funcionario funcionario) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // anota pagamento
        ficha.setEntrega(true);
        // anota funcionario que fez a entrega
        ficha.setF2(funcionario);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaPlano(Identificador id, List<Etapa> plano) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // servico associado (tem de ser programado)
        ServicoProgramado servico = (ServicoProgramado) ficha.getServico();
        // anota plano
        servico.setPlanoTrabalhos(plano);
        // registar na ficha
        ficha.setServico(servico);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public void anotaOrcamento(Identificador id, Orcamento orcamento) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        // servico associado (tem de ser programado)
        ServicoProgramado servico = (ServicoProgramado) ficha.getServico();
        // anota plano
        servico.setOrcamento(orcamento);
        // registar na ficha
        ficha.setServico(servico);
        // adiconar ficha ao sistema
        this.fichas.put(id.getNif(),ficha);
    }

    @Override
    public boolean validaNif(Identificador id) {
        // verifica se o id existe no sistema
        return this.fichas.containsKey(id.getNif());
    }

    @Override
    public boolean verificaServicoExpresso() {
        LocalDateTime time = LocalDateTime.now();
        int minuto = time.getMinute();
        return (minuto % 2) == 0;
    }

    @Override
    public boolean verificaPagamento(Identificador id) {
        // ficha com id correspondente
        FichaRegisto ficha = this.fichas.get(id.getNif());
        return ficha.getPagamento();
    }

    @Override
    public void addPedidoOrcamento(Identificador id) {
        // adiciona à lista de pedidos de orcamento
        this.listaPedidosOrcamento.add(id.clone());
    }

    @Override
    public void addEquipamentoPorReparar(Identificador id) {
        // adiciona à lista de equipamentos por reparar
        this.listaEquiPorReparar.add(id.clone());
    }

    @Override
    public void addEquipamentoReparado(Identificador id) {
        // adiciona à lista de equipamentos reparados
        this.listaEquiReparados.add(id.clone());
    }

    @Override
    public void eliminaPedidoOrcamento(Identificador id) {
        // elimina da lista de pedidos de orcamento
        this.listaPedidosOrcamento.remove(id);
    }

    @Override
    public void eliminaEquipamentoPorReparar(Identificador id) {
        // elimina da lista de equipamentos por reparar
        this.listaEquiPorReparar.remove(id);
    }

    @Override
    public void eliminaEquipamentoReparado(Identificador id) {
        // elimina da lista de equipamentos reparados
        this.listaEquiReparados.remove(id);
    }

    @Override
    public Orcamento calculaOrcamento(List<Etapa> plano) {
        Orcamento orcamento = new Orcamento();
        orcamento.calculaOrcamento(plano);
        return orcamento;
    }

    @Override
    public boolean realizaEtapas(ServicoProgramado servico) {
        System.out.println("Começo da reparação, técnico " + servico.getTecnico() + "\n");
        ServicoProgramado sp = new ServicoProgramado(servico);
        return sp.realizaEtapas();
    }

    @Override
    public void anotaContactoCliente(ServicoProgramado servico, LocalDateTime data) {
        ServicoProgramado sp = new ServicoProgramado(servico);
        sp.anotaContactoCliente(data);
    }

    // metodos gestao utilizadores
    @Override
    public boolean validaCredenciais(String numero, String password) {
        // utilizador com numero correspondente
        Utilizador utilizador = this.utilizadores.get(numero);
        if (utilizador == null) return false;
        // compara numero do utilizador
        boolean num = utilizador.getNumero().equals(numero);
        // compara password do utilizador
        boolean pass = utilizador.getPassword().equals(password);
        return num && pass;
    }

    @Override
    public void incrementaRececao(Funcionario funcionario) {
        // incrementa rececoes do funcionario
        funcionario.incrementaRececoes();
        // regista no sistema
        this.utilizadores.put(funcionario.getNumero(), funcionario);
    }

    @Override
    public void incrementaEntrega(Funcionario funcionario) {
        // incrementa entregas do funcionario
        funcionario.incrementaEntregas();
        // regista no sistema
        this.utilizadores.put(funcionario.getNumero(), funcionario);
    }

    @Override
    public void incrementaServicoProgramado(Tecnico tecnico) {
        // incrementa servicos programados do tecnico
        tecnico.incrementaServicoProgramado();
        // regista no sistema
        this.utilizadores.put(tecnico.getNumero(), tecnico);
    }

    @Override
    public void incrementaServicoExpresso(Tecnico tecnico) {
        // incrementa servicos expresso do tecnico
        tecnico.incrementaServicoExpresso();
        // regista no sistema
        this.utilizadores.put(tecnico.getNumero(), tecnico);
    }

    @Override
    public void registaTempoTrabalho(Tecnico tecnico, int tempo) {
        // incrementa tempo de trabalho do tecnico
        tecnico.registaTempoTrabalho(tempo);
        // regista no sistema
        this.utilizadores.put(tecnico.getNumero(), tecnico);
    }

    @Override
    public String calcularListaTecnicos() {
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<String, Utilizador> entry: this.getUtilizadores().entrySet()) {
            Utilizador utilizador = entry.getValue();
            if (utilizador instanceof Tecnico tecnico)
                sb.append("Técnico ").append(tecnico).append("\n");
        }

        return sb.toString();
    }

    @Override
    public String calcularListaFuncionarios() {
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<String, Utilizador> entry: this.getUtilizadores().entrySet()) {
            Utilizador utilizador = entry.getValue();
            if (utilizador instanceof Funcionario funcionario)
                sb.append("Funcionário ").append(funcionario).append("\n");
        }

        return sb.toString();
    }

    @Override
    public String calcularListaExaustivaTecnicos() {
        return "Ainda não está implemetado...";
    }
}
