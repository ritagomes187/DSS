package Business.Servico;

import Business.Utilizador.Tecnico;

public abstract class Servico {

    private Tecnico tecnico;           // técnico responsável pelo serviço
    // private LocalDateTime inicio;   // data do inicio da reparação
    // private LocalDateTime fim;      // data do fim de reparação

    public Servico() {
        this.tecnico = new Tecnico();
    }

    public Servico(Tecnico tecnico) {
        this.tecnico = tecnico.clone();
    }

    public Servico(Servico servico) {
        this.tecnico = servico.getTecnico();
    }

    // gets
    public Tecnico getTecnico() {
        return this.tecnico;
    }

    // sets
    public void setTecnico(Tecnico tecnico) {
        this.tecnico = tecnico.clone();
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("     Técnico responsável pelo serviço: ").append(this.tecnico);
        return sb.toString();
    }

    // clone
    public abstract Servico clone();

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Servico servico = (Servico) obj;
        return this.tecnico.equals(servico.getTecnico());
    }
}