package Business.Servico;

import Business.Utilizador.Tecnico;

public class ServicoExpresso extends Servico {

    private String tipo;    // tipo de reparação (substituir ecrã, instalar SO)
    private int tempo;      // tempo do serviço
    private float preco;    // preço do serviço

    public ServicoExpresso() {
        super();
        this.tipo = "n/a";
        this.tempo = 0;
        this.preco = 0;
    }

    public ServicoExpresso(Tecnico tecnico, String tipo, int tempo, float preco) {
        super(tecnico);
        this.tipo = tipo;
        this.tempo = tempo;
        this.preco = preco;
    }

    public ServicoExpresso(ServicoExpresso servicoExpresso) {
        super(servicoExpresso);
        this.tipo = servicoExpresso.getTipo();
        this.tempo = servicoExpresso.getTempo();
        this.preco = servicoExpresso.getPreco();
    }

    // gets
    public String getTipo() {
        return this.tipo;
    }
    public int getTempo() {
        return this.tempo;
    }
    public float getPreco() {
        return this.preco;
    }

    // sets
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public void setPreco(float preco) {
        this.preco = preco;
    }
    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("Tipo de serviço: serviço expresso").append("\n");
        sb.append("Tempo do serviço: ").append(this.tempo).append(" minutos").append("\n");
        sb.append("Preço do serviço: ").append(this.preco).append(" euros").append("\n");
        return sb.toString();
    }

    // clone
    public ServicoExpresso clone() {
        return new ServicoExpresso(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        ServicoExpresso servico = (ServicoExpresso) obj;
        return  super.equals(servico) &&
                this.tipo.equals(servico.getTipo()) &&
                this.tempo == servico.getTempo() &&
                this.preco == servico.getPreco();
    }
}