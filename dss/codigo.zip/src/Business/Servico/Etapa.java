package Business.Servico;

import java.util.Scanner;

public class Etapa {

    public boolean realizada;   // indica se a etapa ja foi realizada ou nao
    public int previsaoTempo;   // previsao de tempo para a execução da etapa em minutos
    public float custo;         // custo das peças a utilizar
    public int tempoReal;       // tempo utilizado para execução da etapa em minutos
    public float custoReal;     // custo real das peças utilizadas

    public Etapa(int previsaoTempo, float custo) {
        this.realizada = false;
        this.previsaoTempo = previsaoTempo;
        this.custo = custo;
        this.tempoReal = 0;
        this.custoReal = 0;
    }

    public Etapa(Etapa etapa) {
        this.realizada = etapa.getRealizada();
        this.previsaoTempo = etapa.getPrevisaoTempo();
        this.custo = etapa.getCusto();
        this.tempoReal = etapa.getTempoReal();
        this.custoReal = etapa.getCustoReal();
    }

    // gets
    public boolean getRealizada() {
        return this.realizada;
    }
    public int getPrevisaoTempo() {
        return this.previsaoTempo;
    }
    public float getCusto() {
        return this.custo;
    }
    public int getTempoReal() {
        return this.tempoReal;
    }
    public float getCustoReal() {
        return this.custoReal;
    }

    // sets
    public void setRealizada(boolean realizada) {
        this.realizada = realizada;
    }
    public void setPrevisaoTempo(int previsaoTempo) {
        this.previsaoTempo = previsaoTempo;
    }
    public void setCusto(float custo) {
        this.custo = custo;
    }
    public void setTempoReal(int tempoReal) {
        this.tempoReal = tempoReal;
    }
    public void setCustoReal(float custoReal) {
        this.custoReal = custoReal;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder("Detalhes da etapa\n");
        sb.append("Previsão de tempo: ").append(this.previsaoTempo).append(" minutos").append("\n");
        sb.append("Custo das peças: ").append(this.custo).append(" euros").append("\n");
        return sb.toString();
    }

    // clone
    public Etapa clone() {
        return new Etapa(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Etapa etapa = (Etapa) obj;
        return  this.custo == etapa.getCusto() &&
                this.previsaoTempo == etapa.getPrevisaoTempo();
    }

    // metodos
    public boolean realizaEtapa() {
        Scanner in = new Scanner(System.in);
        String espera;
        System.out.println("Tempo previsto = " + this.previsaoTempo);
        System.out.println("Custo previsto = " + this.custo);
        System.out.println("Colocar realização da etapa em espera ? (sim ou nao)"); espera = in.nextLine();
        if (espera.equals("sim")) {
            this.realizada = false;
            return false;
        } else { // espera.equals("nao")
            this.realizada = true;
            System.out.println("Tempo utilizado = ");
            this.tempoReal = Integer.parseInt(in.nextLine());
            System.out.println("Custo real = ");
            this.custoReal = Float.parseFloat(in.nextLine());
            return true;
        }
    }
}
