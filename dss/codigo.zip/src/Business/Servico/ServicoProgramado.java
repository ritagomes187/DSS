package Business.Servico;

import Business.Utilizador.Tecnico;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ServicoProgramado extends Servico {

    private boolean pedidoOrcamento;            // cliente efetuou pedido de orçamento ?
    private boolean confirmacaoOrcamento;       // cliente aceitou orçamento ?
    private float preco;                        // preço final
    private List<Etapa> planoTrabalhos;         // plano de trabalhos realizado pelo técnico
    private Orcamento orcamento;                // orçamento calculado apartir do plano de trabalhos
    private LocalDateTime data;                 // data em que o cliente foi contactado (caso seja preciso notificar sobre orcamento excedido)

    public ServicoProgramado() {
        super();
        this.pedidoOrcamento = false;
        this.confirmacaoOrcamento = false;
        this.preco = 0;
        this.planoTrabalhos = new ArrayList<>();
        this.orcamento = new Orcamento();
        this.data = null;
    }

    public ServicoProgramado(Tecnico tecnico, boolean pedidoOrcamento, boolean confirmacaoOrcamento, float preco,
                             List<Etapa> planoTrabalhos, Orcamento orcamento, LocalDateTime data) {
        super(tecnico);
        this.pedidoOrcamento = pedidoOrcamento;
        this.confirmacaoOrcamento = confirmacaoOrcamento;
        this.preco = preco;
        this.planoTrabalhos = planoTrabalhos.stream().map(Etapa::clone).collect(Collectors.toList());
        this.orcamento = orcamento.clone();
        this.data = data;
    }
    public ServicoProgramado(ServicoProgramado servicoProgramado) {
        super(servicoProgramado);
        this.pedidoOrcamento = servicoProgramado.getPedidoOrcamento();
        this.confirmacaoOrcamento = servicoProgramado.getConfirmacaoOrcamento();
        this.preco = servicoProgramado.getPreco();
        this.planoTrabalhos = servicoProgramado.getPlanoTrabalhos();
        this.orcamento = servicoProgramado.getOrcamento();

    }

    // gets
    public boolean getPedidoOrcamento() {
        return this.pedidoOrcamento;
    }
    public boolean getConfirmacaoOrcamento() {
        return this.confirmacaoOrcamento;
    }
    public float getPreco() {
        return this.preco;
    }
    public List<Etapa> getPlanoTrabalhos() {
        return this.planoTrabalhos.stream().map(Etapa::clone).collect(Collectors.toList());
    }
    public Orcamento getOrcamento() {
        return this.orcamento.clone();
    }
    public LocalDateTime getData() {
        return this.data;
    }

    // sets
    public void setPedidoOrcamento(boolean pedidoOrcamento) {
        this.pedidoOrcamento = pedidoOrcamento;
    }
    public void setConfirmacaoOrcamento(boolean confirmacaoOrcamento) {
        this.confirmacaoOrcamento = confirmacaoOrcamento;
    }
    public void setPreco(float preco) {
        this.preco = preco;
    }
    public void setPlanoTrabalhos(List<Etapa> planoTrabalhos) {
        this.planoTrabalhos = planoTrabalhos.stream().map(Etapa::clone).collect(Collectors.toList());
    }
    public void setOrcamento(Orcamento orcamento) {
        this.orcamento = orcamento.clone();
    }
    public void setData(LocalDateTime data) {
        this.data = data;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("     Tipo de serviço: serviço programado").append("\n");
        sb.append("     Cliente pediu orçamento ? ").append(this.pedidoOrcamento).append("\n");
        sb.append("     Cliente aceitou orçamento ? ").append(this.confirmacaoOrcamento).append("\n");
        sb.append("     Preço final do serviço: ").append(this.preco).append(" euros").append("\n");
        sb.append("     Plano de trabalhos: ").append(this.planoTrabalhos.toString()).append("\n");
        sb.append(this.orcamento.toString());
        return sb.toString();
    }

    // clone
    public ServicoProgramado clone() {
        return new ServicoProgramado(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        ServicoProgramado servico = (ServicoProgramado) obj;
        return  super.equals(servico) &&
                this.pedidoOrcamento == servico.getPedidoOrcamento() &&
                this.confirmacaoOrcamento == servico.getConfirmacaoOrcamento() &&
                this.preco == servico.getPreco() &&
                this.planoTrabalhos.equals(servico.getPlanoTrabalhos()) &&
                this.orcamento.equals(servico.getOrcamento());
    }

    // metodos
    public boolean realizaEtapas() {
        for (int i = 0; i < this.planoTrabalhos.size(); i++) {
            Etapa etapa = this.planoTrabalhos.get(i);
            boolean realizada = etapa.getRealizada();
            if (realizada)
                System.out.println("ETAPA Nº" + i + 1 + " já realizada.");
            else {
                System.out.println("ETAPA Nº" + i + 1);
                boolean realizouEtapa = etapa.realizaEtapa();
                if (realizouEtapa) {
                    System.out.println("ETAPA Nº" + i + 1 + " realizada.");
                    this.preco += etapa.getCustoReal() + (5*((float) etapa.getTempoReal()/60));
                }
                else {
                    System.out.println("ETAPA Nº" + i + 1 + " interrompida.");
                    return false;
                }
            }
        }
        return true;
    }

    public void anotaContactoCliente(LocalDateTime data) {
        this.setData(data);
    }

    public boolean orcamentoExcedido() {
        float custoFinal = this.preco;
        float custoPrevisto = this.orcamento.getValor();
        return custoFinal > 1.2*custoPrevisto;
    }
}