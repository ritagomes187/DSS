package Business.Servico;

import java.time.LocalDateTime;
import java.util.List;

public class Orcamento {

    public float valor;             // valor previsto
    public LocalDateTime prazo;     // prazo previsto

    public Orcamento() {
        this.valor = 0;
        this.prazo = null;
    }

    public Orcamento(float valor, LocalDateTime prazo) {
        this.valor = valor;
        this.prazo = prazo;
    }

    public Orcamento(Orcamento orcamento) {
        this.valor = orcamento.getValor();
        this.prazo = orcamento.getPrazo();
    }

    // gets
    public float getValor() {
        return this.valor;
    }
    public LocalDateTime getPrazo() {
        return this.prazo;
    }

    // sets
    public void setValor(float valor) {
        this.valor = valor;
    }
    public void setPrazo(LocalDateTime prazo) {
        this.prazo = prazo;
    }

    // toString
    public String toString() {
        StringBuilder sb = new StringBuilder("Detalhes do orçamento\n");
        sb.append("     Valor previsto: ").append(this.valor).append(" euros").append("\n");
        sb.append("     Prazo previsto: ").append(this.prazo).append("\n");
        return sb.toString();
    }

    // clone
    public Orcamento clone() {
        return new Orcamento(this);
    }

    // equals
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Orcamento orcamento = (Orcamento) obj;
        return  this.valor == orcamento.getValor() &&
                this.prazo.equals(orcamento.getPrazo());
    }

    // metodos
    public void calculaOrcamento(List<Etapa> plano) {
        int tempoTotal = 0;
        float custoTotal = 0;
        for (Etapa etapa : plano) {
            tempoTotal += etapa.getPrevisaoTempo();
            custoTotal += etapa.getCusto();
        }
        // custo total das peças + 5 euros por hora
        this.valor = custoTotal + (5*((float) tempoTotal/60));
        // por cada 60 min de trabalho o prazo aumenta 1 dia
        this.prazo = LocalDateTime.now().plusDays(tempoTotal/60);
    }
}
