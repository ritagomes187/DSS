package Business;

import Business.Utilizador.Funcionario;
import Business.Utilizador.Tecnico;

public interface IUtilizadores {

    /**
     * Método responsável por validar as credenciais de um utilizador
     * @param numero Número do utilizador
     * @param password Password do utilizador
     * @return true, se válidas, false caso contrário
     */
    boolean validaCredenciais(String numero, String password);

    /**
     * Método responsável por incrementar as receções de equipamentos de um funcionário
     * @param funcionario O funcionário
     */
    void incrementaRececao(Funcionario funcionario);

    /**
     * Método responsável por incrementar as entregas de equipamentos de um funcionário
     * @param funcionario O funcionário
     */
    void incrementaEntrega(Funcionario funcionario);

    /**
     * Método responsável por incrementar os serviços programados de um técnico
     * @param tecnico O técnico
     */
    void incrementaServicoProgramado(Tecnico tecnico);

    /**
     * Método responsável por incrementar os serviços expressos de um técnico
     * @param tecnico O técnico
     */
    void incrementaServicoExpresso(Tecnico tecnico);

    /**
     * Método responsável por registar o tempo de trabalho de um técnico
     * @param tecnico O técnico
     * @param tempo Tempo de trabalho exercido por um técnico em minutos
     */
    void registaTempoTrabalho(Tecnico tecnico, int tempo);

    /**
     * Método responsável por listar o número de reparações programadas/expresso,
     * a duração média das reparações programadas e a média dos desvios em relação
     * às durações previstas de cada técnico
     * @return A lista em formato String
     */
    String calcularListaTecnicos();

    /**
     * Método responsável por listar o número de receções e entregas de cada funcionário
     * @return A lista em formato String
     */
    String calcularListaFuncionarios();

    /**
     * Método responsável por fazer uma listagem exaustiva de todas as intrevenções de
     * cada técnico
     * @return A lista em formato String
     */
    String calcularListaExaustivaTecnicos();
}
