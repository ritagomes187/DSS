package Exceptions;

public class EquipamentoNaoReparadoException extends Exception {
    public EquipamentoNaoReparadoException(String s) {
        super(s);
    }
}
