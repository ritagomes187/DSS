package Exceptions;

public class CredenciaisException extends Exception {
    public CredenciaisException(String s) {
        super(s);
    }
}
