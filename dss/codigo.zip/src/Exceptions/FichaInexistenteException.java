package Exceptions;

public class FichaInexistenteException extends Exception {
    public FichaInexistenteException(String s) {
        super(s);
    }
}
