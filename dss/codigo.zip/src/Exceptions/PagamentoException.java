package Exceptions;

public class PagamentoException extends Exception {
    public PagamentoException(String s) {
        super(s);
    }
}
