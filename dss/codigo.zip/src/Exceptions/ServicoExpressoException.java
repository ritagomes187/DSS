package Exceptions;

public class ServicoExpressoException extends Exception {
    public ServicoExpressoException(String s) {
        super(s);
    }
}
