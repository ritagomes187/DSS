package Exceptions;

public class PedidoOrcamentoExcpetion extends Exception {
    public PedidoOrcamentoExcpetion(String s) {
        super(s);
    }
}
