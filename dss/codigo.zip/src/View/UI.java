package View;

import Business.Servico.Etapa;
import Business.Registo.Identificador;
import Business.UseCases;
import Business.Utilizador.Funcionario;
import Business.Utilizador.Gestor;
import Business.Utilizador.Tecnico;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 * NOTAS:
 *
 */

public class UI {

    private UseCases useCases;
    private Menu menu;
    private Scanner scan;

    private static String[] opcoes1 = {"Autenticar-se"};
    private static String[] opcoes2 = { // Funcionário
                                        "Registar receção do equipamento", // 1
                                        "Registar pedido orçamento", // 2
                                        "Confirmar pedido orçamento", // 3
                                        "Registar pagamento", // 4
                                        "Registar entrega do equipamento", // 5
                                        };
    private static String[] opcoes3 = { // Técnico
                                        "Aceder à lista de pedidos de orçamento", // 1
                                        "Registar plano de trabalhos", // 2
                                        "Aceder à lista de equipamentos por reparar", // 3
                                        "Realizar reparação", // 4
                                        "Registar conclusão de reparação", // 5
                                        };
    private static String[] opcoes4 = { // Gestor
                                        "Consultar lista dos técnicos", // 1
                                        "Consultar lista dos funcionários", // 2
                                        "Consultar lista exaustiva dos técnicos" // 3
                                        };

    public UI() {
        this.menu = new Menu(opcoes1);
        this.useCases = new UseCases();
        this.scan = new Scanner(System.in);
    }

    public void run() {
        boolean autenticacao = false;
        while (this.menu.getOpcao() != 0) {
            this.menu.execute();
            if (!autenticacao && this.menu.getOpcao() == 1)
            {
                autenticacao = autenticacao();
                if (autenticacao) {
                    if (this.useCases.getUser() instanceof Funcionario) this.menu = new Menu(opcoes2);
                    if (this.useCases.getUser() instanceof Tecnico) this.menu = new Menu(opcoes3);
                    if (this.useCases.getUser() instanceof Gestor) this.menu = new Menu(opcoes4);
                }
            }
            else
            {
                if (autenticacao && this.useCases.getUser() instanceof Funcionario) {
                    switch (this.menu.getOpcao()) {
                        case  1 -> registarEntregaEquipamentoPeloCliente();
                        case  2 -> registarPedidoOrcamento();
                        case  3 -> confirmacaoPedidoOrcamento();
                        case  4 -> registarPagamento();
                        case  5 -> registarEntregaEquipamentoPeloFuncionario();
                    }
                }
                if (autenticacao && this.useCases.getUser() instanceof Tecnico) {
                    switch (this.menu.getOpcao()) {
                        case 1 -> acederPedidosOrcamento();
                        case 2 -> registarPlanoTrabalhos();
                        case 3 -> acederEquipamentosPorReparar();
                        case 4 -> realizarReparacao();
                        case 5 -> registarConclusaoReparacao();
                    }
                }
                if (autenticacao && this.useCases.getUser() instanceof Gestor) {
                    switch (this.menu.getOpcao()) {
                        case 1 -> consultarListaTecnicos();
                        case 2 -> consultarListaFuncionarios();
                        case 3 -> consultarListaExaustivaTecnicos();
                    }
                }
            }
        }
        System.out.println("A sair do centro de reparações...");
    }

    // Utilizador

    public boolean autenticacao () {
        String numero = null;
        String password = null;
        boolean sucesso = false;

        while (!sucesso) {
            try {
                System.out.print("\nInsira o seu numero de utilizador: ");
                numero = scan.nextLine();
                System.out.print("Insira a sua password: ");
                password = scan.nextLine();
            } catch (InputMismatchException e) {
                System.out.println(e.toString());
            }

            sucesso = this.useCases.autenticacao(numero,password);

            if (!sucesso) System.out.println("Os dados que inseriu não são válidos, tente novamente.\n");
        }
        System.out.println("Autenticação realizada com sucesso !!!");
        return sucesso;
    }

    // Funcionario

    public void registarEntregaEquipamentoPeloCliente() {
        System.out.println("Dados para a criação da ficha de registos...");
        System.out.print("--NIF: "); String nif = this.scan.nextLine();
        System.out.print("--Telemóvel: "); String tlm = this.scan.nextLine();
        System.out.print("--Email: "); String email = this.scan.nextLine();
        System.out.print("--Nome equipamento: "); String nome = this.scan.nextLine();
        System.out.print("--Descrição: "); String descricao = this.scan.nextLine();
        System.out.print("--Tipo de serviço (programado ou expresso): "); String tipoServico = this.scan.nextLine();
        while (!(tipoServico.equals("programado") || tipoServico.equals("expresso"))) {
            System.out.print("Serviço indisponível, tente novamente: ");
            tipoServico = this.scan.nextLine();
        }

        this.useCases.registarEntregaEquipamentoPeloCliente(Integer.parseInt(nif),tipoServico,tlm,email,nome,descricao);
    }

    public void registarPedidoOrcamento() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();
        this.useCases.registarPedidoOrcamento(Integer.parseInt(nif));
    }

    public void confirmacaoPedidoOrcamento() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();
        System.out.print("Insira resposta do cliente (sim ou nao): ");
        String resposta = this.scan.nextLine();
        while (!(resposta.equals("sim") || resposta.equals("nao"))) {
            System.out.print("Resposta desconhecida, tente novamente: ");
            resposta = this.scan.nextLine();
        }

        this.useCases.confirmacaoPedidoOrcamento(Integer.parseInt(nif),resposta);
    }

    public void registarPagamento() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();
        this.useCases.registarPagamento(Integer.parseInt(nif));
    }

    public void registarEntregaEquipamentoPeloFuncionario() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();

        this.useCases.registarEntregaEquipamentoPeloFuncionario(Integer.parseInt(nif));
    }

    // Tecnico

    public void acederPedidosOrcamento() {
        List<Identificador> lista = this.useCases.acederPedidosOrcamento();
        System.out.println(" -> Lista de pedidos de orçamento\n");
        System.out.println("-Mais antigo");
        for (Identificador id: lista)
            System.out.print(id.toString());
        System.out.println("-Mais recente");
    }

    public void registarPlanoTrabalhos() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();

        System.out.println("Detalhes do plano de trabalhos");
        List<Etapa> plano = new ArrayList<>();
        System.out.print("      Número de etapas: "); int etapas = Integer.parseInt(this.scan.nextLine());
        for (int i = 1; i <= etapas; i++) {
            System.out.println("        Etapa " + i);
            System.out.print("        tempo: "); int tempo = Integer.parseInt(this.scan.nextLine());
            System.out.print("        custo: "); float custo = Float.parseFloat(this.scan.nextLine());
            plano.add(new Etapa(tempo,custo));
        }

        this.useCases.registarPlanoTrabalhos(Integer.parseInt(nif), plano);
    }

    public void acederEquipamentosPorReparar() {
        List<Identificador> lista = this.useCases.acederEquipamentosPorReparar();
        System.out.println(" -> Lista de equipamentos por reparar\n");
        System.out.println("-Mais antigo");
        for (Identificador id: lista)
            System.out.print(id.toString());
        System.out.println("-Mais recente");
    }

    public void realizarReparacao() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();
        this.useCases.realizarReparacao(Integer.parseInt(nif));
    }

    public void registarConclusaoReparacao() {
        System.out.print("Insira o NIF do cliente: ");
        String nif = this.scan.nextLine();
        this.useCases.registarConclusaoReparacao(Integer.parseInt(nif));
    }

    // Gestor

    public void consultarListaTecnicos() {
        System.out.println(" -> Lista dos técnicos\n");
        System.out.println(this.useCases.consultarListaTecnicos());
    }

    public void consultarListaFuncionarios() {
        System.out.println(" -> Lista dos funcionários\n");
        System.out.println(this.useCases.consultarListaFuncionarios());
    }

    public void consultarListaExaustivaTecnicos() {
        System.out.println(" -> Lista exaustiva dos técnicos\n");
        System.out.println(this.useCases.consultarListaExaustivaTecnicos());
    }
}
